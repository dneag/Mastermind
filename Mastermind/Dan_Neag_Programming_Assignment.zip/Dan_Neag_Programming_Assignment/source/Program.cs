﻿/*
 * Mastermind 
 * Matrix Pointe Software programming assignment
 * 2/24/2024
 */

Mastermind.Game game = new();
game.Start();